//
//  dct_test.h
//  pictureCodec
//
//  Created by jameswoods on 11/28/16.
//  Copyright © 2016 jameswoods. All rights reserved.
//

#ifndef dct_test_h
#define dct_test_h
void testDct(void);
#endif /* dct_test_h */
